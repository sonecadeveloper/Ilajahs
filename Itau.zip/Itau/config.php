<?php
$receber = "nesigivaka@xcodes.net" ;
?>